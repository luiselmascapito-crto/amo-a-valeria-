# mi-pagina-interactiva
Una Página Web Interactiva con Pestañas Este ejemplo simula una página de "Información del Producto" con diferentes secciones accesibles a través de pestañas.
